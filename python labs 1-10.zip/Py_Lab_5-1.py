# Write a Python program to Count the occurrences of an element in a tuple.

t1 = (3,4,4,4,2,2,3,6,7,4,4)
print (t1.count(4))