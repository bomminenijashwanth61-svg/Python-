# Write a python code for calculate the area and volume of the Cube.

s = 4

print ("The volume of cube is:", s*s*s)
print ("The area of cube is:", 6*s*s)
