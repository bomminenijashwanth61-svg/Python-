# Write a python code to solve the equation z = (x+y)*(x-y)

x, y, z = 2, 3, 4

print ("If z = (x+y)*(x-y), then z is:", (x+y)*(x-y))
