# Write a Python program to reverse a string.

str1 = "ICT Department"
rev_str1 = ""
for char in str1:
    rev_str1 = char + rev_str1
print (rev_str1)
