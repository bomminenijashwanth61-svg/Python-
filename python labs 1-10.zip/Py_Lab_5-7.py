# Write a python program to find the first and last elements of a tuple.

num = (7, 2, 8, 5, 9)
print (num[0])
print (num[-1])

