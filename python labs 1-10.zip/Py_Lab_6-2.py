# Write a Python program to find the sum of all natural numbers between 1 to n.

x = 1
n = 5
sum = 0
while x <= n:
    sum += x
    x += 1
print (sum)
