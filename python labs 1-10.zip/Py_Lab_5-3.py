# Write a Python program to Convert a tuple to a string.

t1 = (3,4,4,4,2,2,3,6,7,4,4)
str1 = str(t1)
print (str1)
