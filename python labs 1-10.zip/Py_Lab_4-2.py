# Write a Python program to get the largest number from a list.

list = [24, 53, 87, 65]
print("The largest number is:", max(list))
