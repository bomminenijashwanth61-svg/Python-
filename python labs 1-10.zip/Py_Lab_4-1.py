# Write a python code to multiply all items in a list.

res = 1
a = [2, 4, 6, 3]

for val in a:
    res = res * val
print ("The product of all items in the list is:", res)
