# Write a python code for testing if a number is even or odd

num = 5

if (num % 2 == 0):
    print ("The number:", num, "is even")
else:
    print ("The number", num, "is odd")
    