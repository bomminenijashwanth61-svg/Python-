# Write a python code for Converting Celsius to Fahrenheit

c = 0

print ("Celsius to Fahrenheit is:", (c * 9/5)+32)