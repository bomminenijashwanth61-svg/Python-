# Write a Python program to find the first and last digits of a number.

num = 7234
num = str(num)
print ("The first digit of the number is: ", num[0])
print ("The last digit of the number is: ", num[-1])
