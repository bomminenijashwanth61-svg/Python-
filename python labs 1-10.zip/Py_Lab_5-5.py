# Write a Python program to convert a tuple of strings to a single string.

t1 = ('Hello', 'World')
str1 = str(t1)
print (str1)

