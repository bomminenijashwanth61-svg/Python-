# Write a NumPy program to repeat array elements.

import numpy as np

a = np.array([1, 2, 3])

rev = np.repeat(a, 3)

print("Original array:", a)
print("Repeated array:", rev)
