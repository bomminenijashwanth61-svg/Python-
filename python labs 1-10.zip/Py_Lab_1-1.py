st1 = 'Welcome to Python \n'
print (5*st1)
