# Write a NumPy program to find the 4th element of a specified array.

import numpy as np

a = np.array ([1, 2, 3, 4, 5])
fourth_element = a[3]
print ("The 4th element is: ", fourth_element)
