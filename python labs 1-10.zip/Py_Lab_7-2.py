# Write a NumPy program to reverse an array (the first element becomes the last).

import numpy as np

a = np.array ([1, 2, 3, 4, 5])
rev = a[::-1]
print (rev) 
