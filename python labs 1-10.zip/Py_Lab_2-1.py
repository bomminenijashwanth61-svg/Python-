# Write a python code for calculating the Area and Perimeter of a Rectangle

l = 5
b = 3
print ("Perimeter of rectangle is:", 2*(l+b))
print ("Area of rectangle is:", l*b)
