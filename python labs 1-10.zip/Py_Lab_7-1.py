# Write a NumPy program to create a 3x3 matrix with values ranging from 2 to 10

import numpy as np
l1 = [2, 3, 4]
l2 = [5, 6, 7]
l3 = [8, 9, 10]
a = np.array([l1, l2, l3])
print (a)
