# Write a Python program to sort a tuple of integers.

t1 = [1, 3, 4, 2, 5]
t1 = list(t1)
t1.sort()
print (t1)