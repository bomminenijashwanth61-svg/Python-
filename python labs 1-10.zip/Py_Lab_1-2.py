print("a a^2 a^3")
for a in range (1, 5):
    print(f"{a} {a**2} {a**3}")
    
