# Write a Python program to Check if an element exists in a tuple.

t1 = (3,4,4,4,2,2,3,6,7,4,4)
print (3 in t1)
