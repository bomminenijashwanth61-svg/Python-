# Write a Python program to Find the maximum and minimum elements in a tuple.

numbers = (7, 2, 8, 5, 9)
print(max(numbers))
print(min(numbers))
