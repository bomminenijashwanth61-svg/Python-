# Write a Python program to check if a string contains only digits.

str1 = "6320"

a = str1.isdigit()

if (a == True):
    print ("The string", str1, "only contains digits")
else:
    print ("The string", str1, "does not only contain digits")
