# Write a Python program to find the length of the last word in a sentence.

str1 = "Python Exercises"

words = str1.split()

print ("Length of the last word is: ", len(words[-1]))
