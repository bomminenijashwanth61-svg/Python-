# Write a Python program to print all odd numbers between 1 to 100 using a while loop.

x = 0
while x <= 100:
    if (x % 2 != 0):
        print (x)
    x += 1
    