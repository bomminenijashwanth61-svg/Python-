import math
x = float(input("Enter value of x: "))
y = 6 * x ** 2 + 4 * math.sin(x)
print ("y = ", y)
