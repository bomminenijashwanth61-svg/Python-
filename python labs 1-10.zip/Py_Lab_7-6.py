# Write a NumPy program to create an array of ones and zeros.

import numpy as np

ones = np.ones ([3, 4])
zeros = np.zeros ([3, 4])
print ("Araay of ones is: ", ones)
print ("Araay of zeros is: ", zeros)
