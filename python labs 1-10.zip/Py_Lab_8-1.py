# Write a Python program to convert degree to radian.

from math import *
degree = 45
radian = degree * pi / 180
print ("The convertion of degree to radian is: ", radian)

